﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ContatoWeb.Models;

namespace ContatoWeb.Controllers
{
    public class ContatoController : Controller
    {
        // GET: Contato
        public ActionResult Index()
        {
            using (ContatoModel model = new ContatoModel())
            {
                List<Contato> lista = model.Read();
                return View(lista);
            }
        }

        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(FormCollection form)
        {
            Contato contato = new Contato();
            contato.Nome = form["Nome"];
            contato.DDD1 = form["DDD1"];
            contato.Fone1 = form["Fone1"];
            contato.DDD2 = form["DDD2"];
            contato.Fone2 = form["Fone2"];

            using (ContatoModel model = new ContatoModel())
            {
                model.Create(contato);
                return RedirectToAction("Index");
            }
        }
    }
}